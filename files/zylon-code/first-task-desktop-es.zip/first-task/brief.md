# Plan del taller

Prepara un taller interno para el 14 de noviembre.
El plan debe contener exactamente tres tareas de preparación, con responsable y fecha límite.
Utiliza solo los datos de notes.md. Si falta un responsable, indica Pendiente.
Guarda el plan en plan.md sin modificar los documentos originales.
No contactes con nadie, reserves servicios ni ejecutes comandos.
