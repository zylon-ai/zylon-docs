/** Return whether another reservation fits the available capacity. */
export function canReserve(currentReservations, capacity) {
  return currentReservations <= capacity;
}
