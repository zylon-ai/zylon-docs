# Zylon Code first task / Primera tarea

This tutorial intentionally contains an off-by-one bug. Run npm test using Node.js to see the full-capacity test fail. Fix src/capacity.mjs so a new reservation is accepted only when there is room. No dependency installation is needed.

Este tutorial incluye intencionadamente un fallo en el límite del aforo. Ejecuta npm test con Node.js para ver cómo falla el caso de aforo completo. Corrige src/capacity.mjs para aceptar una reserva solo si queda sitio. No hace falta instalar dependencias.
