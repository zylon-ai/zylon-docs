import test from 'node:test';
import assert from 'node:assert/strict';
import { canReserve } from '../src/capacity.mjs';

test('accepts a reservation while places are available', () => {
  assert.equal(canReserve(9, 10), true);
});
test('refuses a reservation when capacity is full', () => {
  assert.equal(canReserve(10, 10), false);
});
test('refuses a reservation when capacity is exceeded', () => {
  assert.equal(canReserve(11, 10), false);
});
test('accepts a reservation in an empty shop with capacity', () => {
  assert.equal(canReserve(0, 10), true);
});
