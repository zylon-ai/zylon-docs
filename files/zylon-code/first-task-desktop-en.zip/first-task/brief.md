# Workshop plan

Prepare an internal workshop on 14 November.
The plan must contain exactly three preparation tasks, with an owner and a deadline.
Use only the facts in notes.md. Mark missing owners as Pending.
Save the plan as plan.md without changing the source documents.
Do not contact anyone, book services or run commands.
