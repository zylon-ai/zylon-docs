# Notas de la reunión

- Marta preparará las invitaciones para el 10 de noviembre.
- Pablo completará la reserva de la sala del taller como muy tarde el 12 de noviembre.
- Las diapositivas deben estar listas para el 13 de noviembre. Todavía no hay una persona asignada.

El taller será el 14 de noviembre. El presupuesto total no puede superar los 200 EUR.
