# Meeting notes

- Marta will prepare invitations by 10 November.
- Pablo will book the room by 12 November.
- Slides must be ready by 13 November. Nobody has been assigned this task yet.

The workshop is on 14 November. The total budget must not exceed EUR 200.
