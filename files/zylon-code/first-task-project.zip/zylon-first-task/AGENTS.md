# Example project / Proyecto de ejemplo

Reservation logic: src/capacity.mjs. Tests: tests/capacity.test.mjs.
Run npm test. No third-party dependencies are needed.
Preserve unrelated files and keep changes focused on the requested behavior.
Do not publish or deploy this example.
